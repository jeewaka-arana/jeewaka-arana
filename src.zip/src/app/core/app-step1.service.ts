import { Injectable } from '@angular/core';
import { AngularFireDatabase,AngularFireList } from '@angular/fire/database';
import { AppStep1 } from './models/app-step1.model';
// import { from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppStep1Service {

  constructor() { }
}
