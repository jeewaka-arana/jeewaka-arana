export class Searchdoctor {
    // $key : string;
    // DocId:String;
    // FirstName:String;
    // LastName:String;
    // UserName:String;
    // Email:String;
    // Phone:Number;
    // NIC:String;
    // Country:String;
    // City:String;
    // Position:String;
    // RegistrationNumber:String
    // FileUrl:String;
    // Password:String;

    $key : string;
    firstname : string;
    lastname : string;
    number : number;
    ExpYears : number;
}
