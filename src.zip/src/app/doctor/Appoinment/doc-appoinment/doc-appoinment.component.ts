import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doc-appoinment',
  templateUrl: './doc-appoinment.component.html',
  styleUrls: ['./doc-appoinment.component.scss']
})
export class DocAppoinmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
