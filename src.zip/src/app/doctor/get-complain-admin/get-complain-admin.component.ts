import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-complain-admin',
  templateUrl: './get-complain-admin.component.html',
  styleUrls: ['./get-complain-admin.component.scss']
})
export class GetComplainAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
