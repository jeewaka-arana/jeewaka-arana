export class Article {
    description: string;
    img: string;
    newArticle: string;
    title: string;
}
