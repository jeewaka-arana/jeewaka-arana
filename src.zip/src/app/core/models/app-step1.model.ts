export class AppStep1 {
    $key : string;
    firstname : string;
    lastname : string;
    number : number;
}
