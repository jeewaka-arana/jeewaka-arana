export class Patient {
    
    PatId:String;
    FirstName:String;
    LastName:String;
    UserName:String;
    Email:String;
    Phone:Number;
    NIC:String;
    Country:String;
    City:String;
    Password:String;

}
