import { Component, OnInit } from '@angular/core';
//import { IgxTimePickerComponent } from "igniteui-angular";

@Component({
  selector: 'app-timepick',
  templateUrl: './timepick.component.html',
  styleUrls: ['./timepick.component.scss']
})
export class TimepickComponent implements OnInit {


  constructor() { }

  ngOnInit() {
  }

}
