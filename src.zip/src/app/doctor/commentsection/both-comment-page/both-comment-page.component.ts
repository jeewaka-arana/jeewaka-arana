import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-both-comment-page',
  templateUrl: './both-comment-page.component.html',
  styleUrls: ['./both-comment-page.component.scss']
})
export class BothCommentPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
