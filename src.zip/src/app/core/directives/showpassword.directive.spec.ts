import { ShowpasswordDirective } from './showpassword.directive';

describe('ShowpasswordDirective', () => {
  it('should create an instance', () => {
    const directive = new ShowpasswordDirective();
    expect(directive).toBeTruthy();
  });
});
