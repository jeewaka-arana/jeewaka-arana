import { DropZoneDirective } from './drop-zone.directive';

describe('DropZoneDirective', () => {
  it('should create an instance', () => {
    const directive = new DropZoneDirective();
    expect(directive).toBeTruthy();
  });
});
