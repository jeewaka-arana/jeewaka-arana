import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appTimePicker]'
})
export class TimePickerDirective {

  constructor(){
    
  }
}
