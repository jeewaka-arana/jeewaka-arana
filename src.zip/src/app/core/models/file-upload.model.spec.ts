import { FileUpload.Model } from './file-upload.model';

describe('FileUpload.Model', () => {
  it('should create an instance', () => {
    expect(new FileUpload.Model()).toBeTruthy();
  });
});
