import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dfooter',
  templateUrl: './dfooter.component.html',
  styleUrls: ['./dfooter.component.scss']
})
export class DfooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
