import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-docpnav',
  templateUrl: './docpnav.component.html',
  styleUrls: ['./docpnav.component.scss']
})
export class DocpnavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
