import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctorford',
  templateUrl: './doctorford.component.html',
  styleUrls: ['./doctorford.component.scss']
})
export class DoctorfordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
