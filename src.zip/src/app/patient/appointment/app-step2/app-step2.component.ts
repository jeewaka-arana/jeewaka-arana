import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-step2',
  templateUrl: './app-step2.component.html',
  styleUrls: ['./app-step2.component.scss']
})
export class AppStep2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
