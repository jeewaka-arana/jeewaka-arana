import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewbutton',
  templateUrl: './viewbutton.component.html',
  styleUrls: ['./viewbutton.component.scss']
})
export class ViewbuttonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
