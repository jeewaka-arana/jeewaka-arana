import { TimePickerDirective } from './time-picker.directive';

describe('TimePickerDirective', () => {
  it('should create an instance', () => {
    const directive = new TimePickerDirective();
    expect(directive).toBeTruthy();
  });
});
