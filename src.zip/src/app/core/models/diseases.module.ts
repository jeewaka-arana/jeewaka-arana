
export class Disease{
    id:number;
    name:string;
}