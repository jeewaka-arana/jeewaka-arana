export class Star {
    patientId: string;
    doctorId: string;
    value: number;
}
