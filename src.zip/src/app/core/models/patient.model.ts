export class Patient {
    
    Userid:string;
    FirstName:string;
    LastName:string;
    Email:string;
    PhoneNumber:number;
    NIC:string;
    Country:string;
    City:string;
    Day:number;
    Month:number;
    Year:number;

}
